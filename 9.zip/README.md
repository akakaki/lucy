# LUCY

- [figma圖檔](https://www.figma.com/file/b8CCyHfg62qv3DG26N54T5/LUCY_User%E7%AB%AF-(Copy)?node-id=0%3A1)

## 頁面
- [x] 404 : 404
- [x] setting : 設定
- [ ] candidate-response : 面試者資料(html)
- [ ] dropdown : 職缺(html)
- [ ] dropdown-setup-1 : 職缺-step-1
- [ ] dropdown-setup-2 : 職缺-step-2
- [ ] dropdown-setup-3 : 職缺-step-3
- [x] plan : 方案
- [x] record : 交易紀錄
- [x] notification : 通知
- [x] user : 應徵頁面(html)
- [x] user-setup-1 : 應徵頁面-setup-1(html)
- [x] user-setup-2 : 應徵頁面-setup-2-完成(html)
- [x] website : 徵才網站(html)
- [x] index : 露西面試助理
- [x] sign-in : 登入
- [x] sign-up : 註冊
- [x] forget-password-step-1 : 忘記密碼-step-1
- [x] forget-password-step-2 : 忘記密碼-step-2